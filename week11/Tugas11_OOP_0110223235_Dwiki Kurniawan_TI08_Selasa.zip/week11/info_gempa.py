from Gempa import *

# object / instance
banten = Gempa("Banten",1.2)
banten.dampak()
palu = Gempa("Palu",6.1)
palu.dampak()
cianjur = Gempa("Cianjur",5.6)
cianjur.dampak()
jayapura = Gempa("Jayapura",3.3)
jayapura.dampak()
garut = Gempa("Garut",4.0)
garut.dampak()